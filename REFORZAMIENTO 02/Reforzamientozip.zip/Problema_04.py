
"""Problema 04"""
import math

Var1= 4 / 3
Pi= math.pi
radio= 5
radio3 = radio ** 3
Volumen_esf= Var1 *  Pi * radio3
print(Volumen_esf)
