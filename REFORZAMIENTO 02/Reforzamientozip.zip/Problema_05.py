
"""Problema 05"""

sueldo = 2501

if sueldo % 2 == 0:
    print(f"El sueldo de {sueldo} es un número par")
else:
    print(f"El sueldo de {sueldo} es un número impar")

