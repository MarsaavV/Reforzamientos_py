
"""Problema 09"""

numero = 3
exponente = 6


r_potencia = pow(numero, exponente)
r_final = r_potencia - (numero * 2)

print('El resultado es: {}'.format(r_final))
