
"""Problema 12"""

lista_datos = [1, 3.14, "Hola", True, 42]
lista_pares = [2, 4, 6, 8, 10]
lista_combinada = lista_datos + lista_pares
print("Lista combinada:", lista_combinada)

"""Comentario"""
"""Los elementos de la segunda lista se añadieron a los de la primera lista mas no se sumaron o se realizó alguna 
operación aritmética"""