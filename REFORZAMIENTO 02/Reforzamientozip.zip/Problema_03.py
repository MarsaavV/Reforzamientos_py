
"""Problema 03"""

VarStr= "200"
VarInt= 20
Suma= int(VarStr) + (VarInt)
print(Suma)
