
""""Problema 11"""

numero = 4
potencia = numero ** 5
resultado = potencia / 10
tipo_dato = type(resultado)
modulo = resultado % 3

print("El tipo de dato es {}".format(tipo_dato))
print("El modulo es {}".format(modulo))
