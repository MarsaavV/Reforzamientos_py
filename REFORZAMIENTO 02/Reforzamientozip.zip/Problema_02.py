
"""Problema 02"""

var1= 20
Operacion = (var1*10)-10
Conversion= float(Operacion)
print(Conversion)
