
"""Problema 06"""

dato1 = 12.5
dato2 = 7.8
dato3 = 9.6
dato4 = 15.3
dato5 = 8.4

media = (dato1 + dato2 + dato3 + dato4 + dato5) / 5

print("La media es: ", media)
