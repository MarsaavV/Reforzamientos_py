
"""Problema 08"""

lista_vacia = []
lista_no_vacia = [7, 2, 10]

if not lista_vacia:
    print("La lista está vacía.")
else:
    print("La lista no está vacía.")

if not lista_no_vacia:
    print("La lista está vacía.")
else:
    print("La lista no está vacía.")
