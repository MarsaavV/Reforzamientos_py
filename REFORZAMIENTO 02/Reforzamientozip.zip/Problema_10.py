
"""Problema 10"""

diccionario = {
    "nombre": "Livia Saavedra",
    "carrera": "Ingeniería Informática",
    "edad": 18,
    "año de nacimiento": 2006
}


print(diccionario)
