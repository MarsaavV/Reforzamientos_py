
"""Problema 07"""

numero1 = -10
numero2 = 15
numero3 = 23

modulo1 = numero1 % 3
modulo2 = numero2 % 5
modulo3 = numero3 % 7

suma_modulos = modulo1 + modulo2 + modulo3

print(suma_modulos)